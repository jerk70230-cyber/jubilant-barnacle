FIX ПУСТОГО ДВЕРНОГО ПРОЁМА — 17.11.2026

Что исправлено
1. Основная камера принудительно включает слой 28 (PortalWindowLayer), на котором рисуется сам портал.
2. Слой 30 (геометрия следующей комнаты) остаётся скрытым от основной камеры, пока переход отображается через RenderTexture.
3. Маска камеры повторно проверяется в LateUpdate, чтобы другой визуальный скрипт не выключил слой портала во время перехода.
4. V-flip шейдера применяется только на графических API с верхним началом UV RenderTexture. На D3D11 поведение сохранено.
5. Шейдер помещён в Resources/PortalWindow.shader: Resources.Load("PortalWindow") найдёт его и в билде.

Состав архива
- Scripts/Procedural/ProceduralRoomManager.cs
- Resources/PortalWindow.shader
- Resources/PortalWindow.shader.meta

Установка вручную (без установщика)
1. Выйдите из Play Mode и сделайте резервную копию Assets/Scripts/Procedural/ProceduralRoomManager.cs.
2. Удалите или переместите старые Assets/Shaders/PortalWindow.shader и Assets/Shaders/PortalWindow.shader.meta. Не оставляйте две копии одного shader GUID.
3. Распакуйте содержимое архива прямо в папку Assets проекта Unity.
   - Scripts/... заменит соответствующий ProceduralRoomManager.cs.
   - Resources/... создаст Assets/Resources/PortalWindow.shader и его .meta.
4. Не заменяйте ProceduralRoomManager.cs.meta: сохраните существующий GUID компонента менеджера.
5. Дождитесь компиляции Unity и проверьте Console.

Важно
- Изменена только логика видимости портала в ProceduralRoomManager.cs и UV-условие в PortalWindow.shader.
- Физика, генерация комнат, анимация дверей и подтверждение перехода не менялись.
- Unity Play Mode в этой среде запустить нельзя; после установки проверьте обычную дверь и переход в лес отдельно.
